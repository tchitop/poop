#!/bin/bash

rm -f ~/bin/poop
rm -f ~/.poop_config.json
sed -i '' '/export PATH="\$HOME\/bin:\$PATH"/d' ~/.zshrc

echo "[✓] poop wurde entfernt."
