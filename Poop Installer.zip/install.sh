#!/bin/bash

mkdir -p ~/bin
cp poop ~/bin/
chmod +x ~/bin/poop

# Branding-Konfig anlegen
echo '{ "unlocked": false }' > ~/.poop_config.json

# PATH-Erweiterung (falls nötig)
if ! grep -q 'export PATH="$HOME/bin:$PATH"' ~/.zshrc; then
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.zshrc
    echo "[+] PATH hinzugefügt."
fi

echo "[✓] Installation abgeschlossen."
echo "Starte dein Terminal neu oder führe 'source ~/.zshrc' aus."
