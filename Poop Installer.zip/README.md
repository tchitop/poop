# 💩 poop – pip mit Stil

Ersetze `pip` durch `poop` und installiere Python-Pakete mit Humor.

## 🔧 Installation

```bash
git clone https://github.com/yourname/poop-installer.git
cd poop-installer
chmod +x install.sh
./install.sh
```

## ✅ Features

- `poop install ...` = `pip install ...` mit 💩
- Ausgabe mit Farbe + Sound
- „made by unix“ Branding (nicht entfernbar ohne Freischaltung)
- Nur durch Discord-Verifizierung bei `unix#1234` entfernbar

## 🔓 Unlock Branding

Schreib `unix#1234` auf Discord. Du erhältst dann ein Freischalt-Tool.

## ❌ Deinstallation

```bash
./uninstall.sh
```